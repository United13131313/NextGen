<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../main.ui" line="14"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="32"/>
        <source>View Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="39"/>
        <source>View With Plants RND</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="46"/>
        <source>Calculate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="53"/>
        <source>Check For Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="60"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="76"/>
        <source>Calc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="86"/>
        <source>Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="155"/>
        <source>Inch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="160"/>
        <source>CM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="165"/>
        <source>Foot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="170"/>
        <source>mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="175"/>
        <source>Meter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="544"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="140"/>
        <source>Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="197"/>
        <source>Side Panels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="208"/>
        <source>Gloss Black 02</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="213"/>
        <source>Burgendy 03</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="218"/>
        <source>Pearl 08</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="223"/>
        <source>Grey 09</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="228"/>
        <source>Eggplant 10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="233"/>
        <source>Scarlet 11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="238"/>
        <source>Charcoal 13</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="243"/>
        <source>Cobalt 14</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="248"/>
        <source>Orange 70</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="253"/>
        <source>Key Lime Green 76</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="258"/>
        <source>Khaki 22</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="263"/>
        <source>Wheat 26</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="268"/>
        <source>Metallic Expresso ME</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="273"/>
        <source>Matte White 18</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="278"/>
        <source>Matte Black 19</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="283"/>
        <source>Expresso 31</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="288"/>
        <source>Bronze 40</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="293"/>
        <source>Burnt Copper 78</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="298"/>
        <source>Golden Bronze 39</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="303"/>
        <source>Copper 67</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="308"/>
        <source>Gold Dust 33</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="313"/>
        <source>Silver 34</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="318"/>
        <source>Pearlized Silver PS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="323"/>
        <source>Gunmetal 37</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="328"/>
        <source>Sunrise 92</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="333"/>
        <source>Red Clay Glaze 94</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="338"/>
        <source>Java JA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="343"/>
        <source>Gloss White 01</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="348"/>
        <source>Special Red SR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="353"/>
        <source>Special Gold SG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="358"/>
        <source>Dark Sapphire 80</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="363"/>
        <source>Sapphire 81</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="368"/>
        <source>Aquamarine 82</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="373"/>
        <source>Blue Diamond 85</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="378"/>
        <source>Garnet 86</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="383"/>
        <source>Golden Quartz 90</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="388"/>
        <source>Burnished Steel 95</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="393"/>
        <source>Burnished Bronze 96</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="398"/>
        <source>Warm White Matte WWM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="403"/>
        <source>Warm White Gloss WNG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="418"/>
        <source>Fastener Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="429"/>
        <source>Dry Wall</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="434"/>
        <source>Masonry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="439"/>
        <source>Wood</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="444"/>
        <source>Metal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="449"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="464"/>
        <source>Lights</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="474"/>
        <source>Wicks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="487"/>
        <source>Boosters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="497"/>
        <source>Hydro Screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="512"/>
        <source>No Drain Btm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="517"/>
        <source>All Drains</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="522"/>
        <source>No Drains</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="533"/>
        <source>Include 8&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="552"/>
        <source>Quote</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
